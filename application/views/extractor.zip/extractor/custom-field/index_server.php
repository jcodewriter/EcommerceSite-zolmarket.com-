<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<title>Data Extractor</title>

	<!-- Bootstrap -->
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
	<link href="<?php echo base_url() ?>assets/css/shieldui-all.min.css" rel="stylesheet"/>

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
</head>
<body class="theme-light">
<div class="container" style="margin-top: 20px;">
	<div class="row">
		<div class="col-md-5">
			<div class="panel panel-default">
				<div class="panel-body">
					<div id="treeview"></div>
					<br/>
					<p><span id="checkedCount"></span></p>
				</div>
			</div>
		</div>
		<div class="col-md-7">
			<div class="panel panel-default" id="custom-fields-panel">
				<div class="panel-body">
					<form class="form-horizontal">
						<div class="form-group">
							<div class="col-md-10">
								<select class="form-control" id="custom-fields"></select>
							</div>
							<div class="col-md-2">
								<button class="btn btn-primary btn-sm" id="export-custom-field">Export</button>
							</div>
						</div>
					</form>
				</div>
				<div class="panel-body" style="min-height: 90vh">
					<table class="table table-bordered table-condensed" id="custom-fields-options">
						<thead>
						<th>#</th>
						<th>name</th>
						<th>english name</th>
						<th>status</th>
						</thead>
						<tbody>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<script src="<?php echo base_url() ?>assets/js/jquery-3.3.1.min.js"></script>
<script src="<?php echo base_url() ?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url() ?>assets/js/shieldui-all.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.blockUI/2.70/jquery.blockUI.js"></script>

<script type="text/javascript">
	function onCheck() {
		// find all LI elements in the treeview and determine how many are checked
		var checkedCount = $("#treeview").swidget("TreeView").element.find("li").filter(function () {
			return $("#treeview").swidget("TreeView").checked($(this));
		}).length;
		$("#checkedCount").html(checkedCount + " items checked");
	}

	function onSelect(e, y) {
		var elementPath = this.getPath(e.element);
		if (elementPath && Array.isArray(elementPath) && elementPath.length > 2) {
			getCategoryItems(e.item.data___id)
		}
	}

	function blockElement(el) {
		$(el).block({
			css: {
				border: 'none',
				padding: '15px',
				backgroundColor: '#000',
				borderRadius: '10px',
				fontSize: '10px',
				opacity: .5,
				color: '#fff'
			}
		});
	}

	function getCategoryItems(catId) {
		$('#custom-fields').empty();
		$('#custom-fields-options tbody').empty();
		blockElement('#custom-fields-panel');
		customFields = {
			ar: [],
			en: []
		};

		$.when(
				$.ajax('https://www.alsoug.com/category-form/' + catId),
				$.ajax('https://www.alsoug.com/en/category-form/' + catId)
		).done(function (resp1, resp2) {
			var data1 = resp1[0];
			var data2 = resp2[0];

			if (data1.status.status == true && data2.status.status == true) {
				customFields = {
					ar: data1.data,
					en: data2.data
				}

				data1.data.forEach(function (customFiled, index) {
					$('<option />')
							.prop('value', index)
							.text(customFiled.display_name).appendTo('#custom-fields')

				});

				$('#custom-fields').trigger('change')
			}
		}).always(function () {
			$('#custom-fields-panel').unblock();
		});


	}
	$(document).on('change', '#export-custom-field', function (event) {

	});

	$(document).on('change', '#custom-fields', function (event) {
		event.preventDefault();
		$('#custom-fields-options tbody').empty();
		var val = $(this).val();
		var arCustomField = customFields.ar[val].options.split('|');
		var enCustomField = customFields.en[val].options.split('|');

		arCustomField.forEach(function (option, index) {
			var enOption = enCustomField[index] || '--';
			$('#custom-fields-options tbody').append(`
				<tr>
					<td>${index + 1}</td>
					<td>${option}</td>
					<td>${enOption}</td>
					<td></td>
				</tr>
			`)
		});
	})

	function bindTree(xItems) {
		$("#treeview").shieldTreeView({
			checkboxes: {
				enabled: false,
				children: false
			},
			events: {
				check: onCheck,
				select: onSelect
			},
			dataSource: {
				data: [
					{
						text: "Root",
						iconUrl: iconUrl,
						expanded: true,
						items: xItems
					}
				]
			}
		});
	}

	const baseUrl = "<?php echo base_url() ?>"
	const iconUrl = baseUrl + 'assets/img/folder.png'
	let categories = {
		ar: [],
		en: []
	};
	let customFields = [];
	$(function () {
		$.when($.ajax('https://www.alsoug.com/adverts/get-search'),
				$.ajax('https://www.alsoug.com/en/adverts/get-search'))
				.done(function (resp1, resp2) {
					categories.ar = resp1[0].data.categories.data;
					var items = parseCategoryChilds(categories.ar);
					bindTree(items);
				});
	})

	function parseCategoryChilds(childs) {
		var result = [];
		childs.forEach(function (xchild, index) {
			var item = {};
			item.data___id = xchild.id;
			item.data__category_name = xchild.category_name;
			item.text = xchild.category_name;
			item.iconUrl = iconUrl;
			item.items = [];
			if (xchild.childs != []) {
				item.items = parseCategoryChilds(xchild.childs);
			}
			result.push(item);
		});
		return result;
	}

</script>
</body>
</html>

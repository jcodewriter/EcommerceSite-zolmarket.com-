<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<title>Data Extractor - Home</title>

	<!-- Bootstrap -->
	<link href="<?php echo base_url() ?>assets/css/bootstrap-3.3.7.min.css" rel="stylesheet">
	<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
	<style>
		body > .container {
			margin-top: 20vh;
		}

		.btn-sq-lg {
			width: 200px !important;
			height: 180px !important;
			margin-bottom: 15px;
			margin-left: 15px;
			padding: 20px;
			text-align: center;

		}
		.btn-sq-lg i {
			display: block;
		}
		.btn-sq-lg span {
			font-size: 1.4em;
			display: block;
			margin-top: 20px;
			word-break: break-all;
			width: 80%;
		}

		.btn-sq {
			width: 100px !important;
			height: 100px !important;
			font-size: 10px;
		}

		.btn-sq-sm {
			width: 50px !important;
			height: 50px !important;
			font-size: 10px;
		}

		.btn-sq-xs {
			width: 25px !important;
			height: 25px !important;
			padding: 2px;
		}


	</style>
</head>
<body class="theme-light">
<div class="container">
	<div class="row">
		<div class="col-lg-12">
			<p>
				<a href="<?php echo site_url('extractor/custom-field') ?>" class="btn btn-sq-lg btn-primary">
					<i class="fa fa-object-ungroup fa-5x"></i>
					<span>Copy Categories</span>
				</a>
				<a href="<?php echo site_url('extractor/category') ?>" class="btn btn-sq-lg btn-success">
					<i class="fa fa-object-ungroup fa-5x"></i>
					<span>Copy Custom Field</span>
				</a>
			</p>
		</div>
	</div>

</div>
<script src="<?php echo base_url() ?>assets/js/jquery-3.3.1.min.js"></script>
<script src="<?php echo base_url() ?>assets/js/bootstrap-3.3.7.min.js"></script>
</body>
</html>

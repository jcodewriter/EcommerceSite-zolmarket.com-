<div class="modal fade" id="change-icon-modal" tabindex="-1" role="dialog"
	 aria-labelledby="change-icon-modal-label">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
				</button>
				<h4 class="modal-title" id="change-icon-modal-label">Change icons</h4>
			</div>
			<div class="modal-body" style="height: 300px;overflow-y: scroll;">
				<table class="table table-bordered">
					<thead>
					<tr>
						<th>#</th>
						<th>Category</th>
						<th>Image</th>
					</tr>
					</thead>
					<tbody>

					</tbody>
				</table>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>

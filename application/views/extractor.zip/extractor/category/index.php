<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<title>Data Extractor - Extracting Category</title>

	<!-- Bootstrap -->
	<link href="<?php echo base_url() ?>assets/css/bootstrap-3.3.7.min.css" rel="stylesheet">
	<link href="<?php echo base_url() ?>assets/css/shieldui-all.min.css" rel="stylesheet"/>
	<link href="<?php echo base_url() ?>assets/css/jstree/themes/default/style.min.css" rel="stylesheet"
	"/>

	<link href="<?php echo base_url() ?>assets/css/bootstrap-select.min.css" rel="stylesheet">

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
	<style>
		body > .container {
			margin-top: 20px;
		}

		.gi-2x {
			font-size: 2em;
		}

		.gi-3x {
			font-size: 3em;
		}

		.gi-4x {
			font-size: 4em;
		}

		.gi-5x {
			font-size: 5em;
		}

		.category-image {
			width: 28px;
			height: 28px;
		}
	</style>
</head>
<body class="theme-light">
<div class="container">
	<div class="row">
		<div class="col-md-6">
			<div class="panel panel-default">
				<div class="panel-heading">
					Copy Categories From
				</div>
				<div class="panel-footer">
					<div class="form-horizontal">
						<div class="form-group">
							<label for="categories-source" class="col-sm-4 control-label">Categories source</label>
							<div class="col-sm-7">
								<select class="form-control" id="categories-source">
									<option value="">Select Source</option>
									<option value="alsoug">Alsoug</option>
									<option value="zolmarket">Zolmarket</option>
								</select>
							</div>
						</div>
					</div>
				</div>
				<div class="panel-body">
					<!-- Nav tabs -->
					<ul class="nav nav-tabs hidden" role="tablist">
						<li role="presentation">
							<a href="#alsoug" aria-controls="alsoug" role="tab" data-toggle="tab">Alsoug</a>
						</li>
						<li role="presentation">
							<a href="#zolmarket" aria-controls="zolmarket" role="tab" data-toggle="tab">Zolmarket</a>
						</li>
					</ul>

					<!-- Tab panes -->
					<div class="tab-content" style="margin-top: 10px">
						<div role="tabpanel" class="tab-pane" id="alsoug">
							<form>
								<div class="form-group">
									<label for="source-category">Category</label>
									<select class="form-control selectpicker" id="source-category"></select>
								</div>
								<div class="form-group">
									<label for="source-sub-category">Sub category</label>
									<select class="form-control selectpicker" id="source-sub-category" multiple
											data-actions-box="true"
											data-selected-text-format="count">
									</select>
								</div>
								<div class="form-group">
									<div class="col-md-8">
										<div class="checkbox">
											<label>
												<input type="checkbox" id="source-copy-icons" checked> Copy icons
											</label>
										</div>
									</div>
									<div class="col-md-4">
										<button class="btn btn-primary btn-sm btn-block"
												type="button"
												data-toggle="modal"
												data-target="#change-icon-modal">Change icons
										</button>
									</div>
								</div>
							</form>
						</div>
						<div role="tabpanel" class="tab-pane" id="zolmarket">


						</div>
					</div>

				</div>
			</div>
		</div>
		<div class="col-md-1 text-center hidden">
			<span class="glyphicon glyphicon-arrow-right gi-2x"></span>
		</div>
		<div class="col-md-6" id="copy-target">
			<div class="panel panel-primary">
				<div class="panel-heading">
					Copy Target
				</div>
				<div class="panel-body">
					<form>
						<input type="hidden" name="parent_id" value="0">
					</form>

				</div>
				<div class="panel-footer text-right">
					<button type="button" class="btn btn-primary" id="save">Save</button>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $this->load->view('extractor/category/modals') ?>
<script src="<?php echo base_url() ?>assets/js/jquery-3.3.1.min.js"></script>
<script src="<?php echo base_url() ?>assets/js/bootstrap-3.3.7.min.js"></script>
<script src="<?php echo base_url() ?>assets/js/jstree.js"></script>
<script src="<?php echo base_url() ?>assets/js/jquery.blockUI.js"></script>
<script src="<?php echo base_url() ?>assets/js/notify.min.js"></script>
<script src="<?php echo base_url() ?>assets/js/bootstrap-select/bootstrap-select.min.js"></script>
<script>
	const csrf = {
		name: '<?php echo $this->security->get_csrf_token_name() ?>',
		hash: '<?php echo $this->security->get_csrf_hash() ?>'
	}
	const baseUrl = "<?php echo base_url() ?>";
	const siteUrl = "<?php echo site_url('/') ?>"
	const blankImageUrl = baseUrl + 'assets/img/orange1x1px.png';
	let data___categories = <?php echo json_encode($categories) ?>;
	const sougCategories = {
		ar: [],
		en: []
	}
	const zolCategories = {
		text: "root",
		id: null,
		items: [],
		subs: []
	};
	const sougCities = {
		ar: [],
		en: []
	};
	let selectedCategories = [];

	function init() {

		$.when($.ajax('https://www.alsoug.com/adverts/get-search'),
				$.ajax('https://www.alsoug.com/en/adverts/get-search'))
				.done(function (arResp, enResp) {

					sougCities.ar = arResp[0].data.cities;
					sougCities.en = enResp[0].data.cities;
					//parse categories
					sougCategories.ar = arResp[0].data.categories.data;
					sougCategories.en = enResp[0].data.categories.data;

					bindCategories(sougCategories.ar, '#source-category');
				});
	}

	function updateSelectedCategories() {
		let sougParentId = $('#source-category').val();
		let xSelectedCategories = [];

		let sougCategoriesHaystack = sougCategories;
		let result = generateSelectedCategoriesItem(sougParentId, sougCategoriesHaystack, null);
		xSelectedCategories.push(result.category);

		let $selectedSubCategoryOptions = $('#source-sub-category option:selected');

		$selectedSubCategoryOptions.each(function () {
			let subId = $(this).val();

			subResult = generateSelectedCategoriesItem(subId, result.childs, sougParentId);
			xSelectedCategories.push(subResult.category);
		});

		selectedCategories = xSelectedCategories;
	}

	function generateSelectedCategoriesItem(categoryId, sougCategoriesHaystack, sougParentId = null) {
		let category = selectedCategories.find(c => c.sougId == categoryId && c.sougParentId == sougParentId);

		let categoryAR = sougCategoriesHaystack.ar.find(c => c.id == categoryId);
		let categoryEN = sougCategoriesHaystack.en.find(c => c.id == categoryId);

		if (category == undefined) {
			category = {
				sougId: categoryId,
				text: categoryAR.category_name,
				name_lang_1: categoryEN.category_name,
				name_lang_2: categoryAR.category_name,
				slug_lang_1: '',
				slug_lang_2: categoryAR.category_slug,
				main_slug: 'main_slug_2',
				visibility: 0,
				show_on_homepage: 0,
				show_image_on_navigation: 1,
				visibility_icon: 1,
				category_order: 1,
				homepage_order: 1,
				file: categoryAR.image_path,
				sougParentId: sougParentId,
				fileOrigin: 'remote'
			};
		}
		return {
			category: category,
			childs: {
				ar: categoryAR.childs,
				en: categoryEN.childs
			}
		}
	}


	function prepareCategories() {
		data___categories.forEach(function (category, index) {
			if (!category.classname) {
				return;
			}
			let classNameParts = category.classname.split('/').filter(x => x != '');
			let classParts = category.class.split('.').filter(x => x != '').map(x => parseInt(x));


			let pointer = zolCategories;


			for (let i = 0; i < classNameParts.length; i++) {
				if (pointer.name != "root" && pointer.subs.length == 0) {
					pointer.subs.push({
						name: "Select Category",
						id: '',
						items: [],
						subs: []
					});
				}
				let cat = pointer.subs.find(c => c.name == classNameParts[i]);
				if (cat == undefined) {
					pointer.subs.push({
						name: classNameParts[i],
						id: classParts[i],
						items: [],
						subs: []
					});
				}
				pointer = pointer.subs.find(c => c.name == classNameParts[i]);
			}


		});
	}

	function bindAddCategoryFormCategories(parentElement, cat, level = 0) {
		let $select = generateSelectBox(parentElement);
		cat.subs.forEach(function (category, index) {
			let $option = $('<option />')
					.val(category.id)
					.data('category', category)
					.data('level', level)
					.text(category.name);

			$select.append($option);

		});

		$select.on('change', function (event) {

			let category = $('option:selected', this).data('category');

			//remove next select element
			$(parentElement + ' select[name^=second_parent_id]:gt(' + level + ')').each(function () {
				$(this).closest('.form-group').remove();
			});
			// $('#copy-target .form-group:gt(' + level + ')').not(':last').remove();

			//if has subs create another select
			if (category.subs.length > 0) {
				bindAddCategoryFormCategories(parentElement, category, level + 1);
			}

		}).trigger('change');


	}

	function generateSelectBox(parentElement) {
		let index = $('[name^=second_parent_id]').length
		let $form_group = $('<div class="form-group"/>').appendTo(parentElement);
		let $select = $(`<select class="form-control" name="second_parent_id[${index}]"/>`).appendTo($form_group);

		return $select;
	}

	function bindCategories(categories, element) {
		//addOption('', '-- الكل --', false);
		$(element).selectpicker('destroy').empty();
		categories.forEach(function (category, index) {
			addOption({
				val: category.id,
				text: category.category_name,
				hasDependency: category.has_dependency || false,
				imageUrl: category.image_path
			});
		});
		$(element).selectpicker().trigger('change');


		function addOption(data) {
			let $option = $('<option />')
					.val(data.val)
					.attr('data-has-dependency', data.hasDependency)
					.text(data.text);

			if (data.imageUrl && RegExp('png|jpg|jpeg', 'g').test(data.imageUrl)) {
				//$option.css('background-image', `url("${imageUrl}")`)
				let content = `<img src="${data.imageUrl}" class="category-image"/> <span>${data.text}</span>`;
				$option.attr('data-content', content);


			} else {
				$option.attr('data-icon', 'glyphicon glyphicon-question-sign gi-2x')
			}
			$option.appendTo(element);
		}
	}

	$(document).on('change', '#categories-source', function (event) {

		let val = $(this).val();
		$('a[href="#' + val + '"]').tab('show')
	})
	$(document).on('change', '#source-copy-icons', function (event) {
		let checked = $(this).prop('checked');
		$('[data-target="#change-icon-modal"]').prop('disabled', !checked)
	});
	$(document).on('click', '[data-target="#change-icon-modal"]', function (event) {
		updateSelectedCategories();
		drawSelectedCategoriesTable();


	});

	function drawSelectedCategoriesTable() {
		let $tbody = $('#change-icon-modal tbody').empty();


		selectedCategories.forEach(function (category, index) {
			drawSelectedCategoryTableRow($tbody, category);
		});
	}

	function drawSelectedCategoryTableRow($tbody, category) {
		let index = $('tr', $tbody).length + 1;
		let isSub = (category.sougParentId !== null);
		let prefix = isSub ? '--' : ''
		let text = prefix + category.text;
		let content = ''
		if (category.fileOrigin == 'remote' && RegExp('png|jpg|jpeg', 'g').test(category.file)) {
			content = `<img src="${category.file}" class="category-image"> ${text}`
		} else if (category.fileOrigin == 'upload') {
			content = `<img src="${blankImageUrl}" class="category-image"> ${text}`
		} else {
			content = `<span class="glyphicon glyphicon-question-sign gi-2x" aria-hidden="true"></span> ${text}`;
		}

		let $tr = $(`<tr data-id="${category.sougId}" data-is-sub="${isSub}">
							<td>${index}</td>
							<td>${content}</td>
							<td><input type="file" class="category-image hidden">
								<button class="btn btn-primary btn-xs change-image">Change Image</button>
							</td>
						</tr>`);
		$tr.appendTo($tbody);

		if (category.fileOrigin == 'upload') {
			readAttachedImage(category.file, function (src) {
				$('img', $tr).prop('src', src);
			})
		}
	}

	function bindSelectedCategoriesToFormData(formData, copyIcons) {

		selectedCategories.forEach((category, index) => {
			Object.entries(category).forEach(([key, value]) => {
				if (key == 'image') {
					return;
				}
				if (!copyIcons && key == 'file') {
					return;
				}
				formData.append(`categories[${index}][${key}]`, value);

			});

		});

	}

	$(document).on('click', '#save', function (event) {
		event.preventDefault();
		const formData = new FormData();
		formData.append(csrf.name, csrf.hash)

		let categoriesSource = $('#categories-source').val();

		if (categoriesSource == 'alsoug') {
			updateSelectedCategories();
			let copyIcons = $('#source-copy-icons').prop('checked');
			formData.append('copyIcons', (copyIcons ? '1' : '0'));
			bindSelectedCategoriesToFormData(formData, copyIcons);

		} else if (categoriesSource == 'zolmarket') {
			$('#zolmarket select[name^=second_parent_id]').each((index, element) => {
				formData.append('zolmarketSourceCategories[' + index + ']', element.value);
			});
		} else {
			$.notify('Please categories source', 'error');
			$('#categories-source').focus();
			return;
		}
		$('#copy-target select[name^=second_parent_id]').each((index, element) => {
			formData.append('copyTarget[' + index + ']', element.value);
		});
		formData.append('categoriesSource', categoriesSource);
		formData.append("parent_id", '0');

		$.ajax({
			url: siteUrl + 'extractor/category/save',
			type: 'POST',
			data: formData,
			// dataType: 'json',
			contentType: false,
			cache: false,
			processData: false,
			success: function (data) {
				if (data.status === 'success') {
					getZolCategories();
					$.notify('data saved successfully.', 'success');
				}

			}
		});

	})
	$(document).on('click', '.change-image', function (event) {
		let $fileInput = $(this).prev('input[type=file]');
		$fileInput.trigger('click');
	});
	$(document).on('change', 'input[type=file].category-image', function (event) {
		let files = event.target.files; // FileList object
		if (files.length < 1) {
			return;
		}
		let xFile = files[0];
		if (xFile.type && xFile.type.indexOf('image') === -1) {
			$.notify('File is not an image.', 'error');
			return;
		}

		let $tr = $(this).closest('tr');
		let $img = $('img', $tr);
		if ($img.length < 1) {
			$('span.glyphicon', $tr).replaceWith('<img />');
		}

		let catId = $tr.data('id');
		let cat = selectedCategories.find(c => c.sougId == catId);
		cat.file = xFile;
		cat.fileOrigin = 'upload';

		/*readAttachedImage(xFile, function (src) {
			let catId = $tr.data('id');

			let cat = selectedCategories.find(c => c.id == catId);
			cat.base64Image = src;
			cat.file = xFile;
			cat.fileOrigin = 'upload';
			drawSelectedCategoriesTable();
		});*/
		drawSelectedCategoriesTable();

	});

	function readAttachedImage(file, callback) {

		const reader = new FileReader();
		reader.addEventListener('load', (event) => {
			callback(event.target.result);
		});
		reader.readAsDataURL(file);
	}

	function readRemoteImage(url, $img) {
		let request = new XMLHttpRequest();
		request.open('GET', url, true);
		request.responseType = 'blob';
		request.onload = function () {
			let reader = new FileReader();
			reader.readAsDataURL(request.response);
			reader.onload = function (event) {
				$img.prop('src', event.target.result);
			};
		};
		request.send();
	}

	$(document).on('change', '#source-category', function (event) {
		event.preventDefault();
		let $option = $('option:selected', this);
		let index = $option.index();
		let val = $(this).val();


		///$('#form-sub-category').selectpicker('destroy').empty();
		if (val) {
			bindCategories(sougCategories.ar[index].childs, '#source-sub-category');
		}

	});

	function blockElement(el) {
		var options = {
			css: {
				border: 'none',
				padding: '15px',
				backgroundColor: '#000000',
				borderRadius: '10px',
				fontSize: '10px',
				opacity: .5,
				color: '#fff'
			}
		};
		if (el) {
			$(el).block(options);
		} else {
			$.blockUI(options);
		}

	}

	function getZolCategories() {
		$.ajax({
			url: siteUrl + 'extractor/category/data/get_categories',
			method: 'GET',
			dataType: 'json',
			success: function (data) {
				data___categories = data;
				prepareCategories();
				$('#copy-target select[name^=second_parent_id]').remove();
				$('zolmarket select[name^=second_parent_id]').remove();
				bindAddCategoryFormCategories('#copy-target form:eq(0)', zolCategories);
				bindAddCategoryFormCategories('#zolmarket', zolCategories);

			}

		});
	}

	$(document).ready(function () {

		$.ajaxSetup({
			beforeSend: function () {
				blockElement();
			},
			complete: function () {
				$.unblockUI();
			}
		});

		init();
		prepareCategories();
		bindAddCategoryFormCategories('#copy-target form:eq(0)', zolCategories);
		bindAddCategoryFormCategories('#zolmarket', zolCategories);
		$('#source-category').trigger('change');
	});

</script>
</body>
</html>
